import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import geopandas as gpd
from shapely.geometry import Point
from dash import Dash, dcc, html, Input, Output
import dash_bootstrap_components as dbc
from datetime import date
import plotly.io as pio
from app import app

pio.templates.default = "plotly"

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

regions_ph = gpd.read_file('Regions.shp')
regions_ph['REGION'].tolist()
LFS=pd.read_excel('LFS.xlsx', sheet_name=2)
LFS_1=pd.read_excel('LFS.xlsx', sheet_name=3)
LFS_2=pd.read_excel('LFS.xlsx', sheet_name=4)
LFS_3=pd.read_excel('LFS.xlsx', sheet_name=5)
LFS_4=pd.read_excel('LFS.xlsx', sheet_name=6)
regions_ph_new=regions_ph.rename(columns={'REGION': 'Region'})
merged_region_01 = regions_ph_new.merge(LFS, on='Region')
merged_region_0=merged_region_01.rename(columns={'Total_Pop_15_Years_Old _and_Over_E': 'Labor_Force_Population'})
merged_region_1 = regions_ph_new.merge(LFS_1, on='Region')
merged_region_2 = regions_ph_new.merge(LFS_2, on='Region')
merged_region_3 = regions_ph_new.merge(LFS_3, on='Region')
merged_region_1 = regions_ph_new.merge(LFS_4, on='Region')

region_dash = merged_region_0[['Labor_Force_Participation_Rate','Employment_Rate','Unemployment_Rate']]
metrics_option_2 = []
for item in region_dash:
  metrics_option_2.append({
      'label': item,
      'value': item
  })

df = pd.read_csv('df_final.csv')
df_2021 = df[df['Date'] == '10/1/2021']
df_2022 = df.drop(index=df[df['Date'] == '10/1/2021'].index)

df_viz6a = pd.read_csv('viz6a.csv')
df_viz6b = pd.read_csv('viz6b.csv')
df_viz7 = pd.read_csv('viz7.csv')

px.set_mapbox_access_token("pk.eyJ1IjoiZmVyZGllMTIzNDUiLCJhIjoiY2xna3diYXQ0MDQ4bzNlcWl5Yzh4ajlxZyJ9.h00WfcnG_51aY_Ovxaw5Vw")

layout = dbc.Container([
    html.Nav(
    html.Ul([
        html.Li([
            html.A('Home', href='/', className='nav-link', style={'border': '1px solid grey'})
        ], className='nav-item'),
        html.Li([
            html.A('Understanding Poverty', href='/page1', className='nav-link', style={'border': '1px solid grey'})
        ], className='nav-item'),
        html.Li([
            html.A('Zooming in on Employment', href='/page2', className='nav-link', style={'border': '1px solid grey'})
        ], className='nav-item'),
        html.Li([
            html.A('Finding Opportunities', href='/page3', className='nav-link', style={'border': '1px solid grey'})
        ], className='nav-item')
    ], className='nav'),
    style={'z-index': '1000'}  # Add this style attribute
),

    # Line Breaks

    html.Div([
        html.Br(), html.Br(), html.Br(), html.Br(), html.Br(),
    ]),

    # Header 2
    html.Section([
        html.H2("Zooming in on Employment", className="text-center mb-3"),
        html.H5("", className="text-center mb-5"),
    ]),

    #Graph1
    html.Div([
        dcc.Dropdown(id="choropleth-select_1", options=metrics_option_2,value='Labor_Force_Participation_Rate'),
        dcc.Graph(id="Map_02")]
    ),

    # Group
    html.Div([
        html.Div([
           html.Label("Select year of interest"),
           dcc.RadioItems(id='raditem4',
                          options = ['2021','2022'],
                          value='2021',
                          style={"width": "50%"}),
            html.Label("Select data of interest"),
            dcc.RadioItems(id='raditem3',
                           options = ['Labor Force','Labor Force and Employment','Labor Force and Unemployment'],
                           value ='Labor Force and Employment',
                           style={"width": "50%"}),
            html.Label("Select island group/s of interest"),
            dcc.Checklist(id='checklist_viz4',
                          options=['Luzon', 'Visayas', 'Mindanao'],
                          value=['Luzon', 'Visayas','Mindanao']),
            html.Div([
                dcc.Graph(id='Viz4')]),
    ],),
        html.Div([
           dcc.RadioItems(id='raditem1',
                    options = [{'label': year, 'value': year} for year in df_viz6a['Year'].unique()],
                    value=df_viz6a['Year'].unique()[0],
                    style={"width": "50%"}),
            html.Div([
                dcc.Graph(id='donut_graph1')
            ]),
    ], className = 'col-7'),

        html.Div([
            html.H6("Intensifying programs for self-employed workers capacitates 27% of employed workers", className="mb-5"),
            html.P("With the recent House of Representatives bill giving protection and incentives to freelancers, the Philippines is slowly being a hub for self-employed professionals such as social media managers, virtual assistants, and consultants. Policymakers can learn a thing or two from this segment whose 21st century skills allow them to be marketable to both local and international clientele. Besides further support for the sector, they can be tapped for collaborations to upskill other groups in society such as out-of-school youth and mothers.", className="mb-5"),
        ], className="page3 col-5"),
    ], className = "row"),

     #Group

     html.Div([
        html.Div([
           html.H6("Still at its infancy at 2.3% share, entrepreneurship can be further accelerated for traditional businesses", className="mb-5"),
            html.P("In the past years, the number of Philippine enterprises accepted to Y Combinator, the world's largest startup incubator, have grown covering cloud kitchens, health tech, edtech, fintech and other industries. There is also massive support for these enterprises, from conglomerates like Aboitiz and Globe to government agencies like the DICT. Still, these are just a fraction of the possible businesses one can open. In the Philippines, traditional businesses are the more familiar pathway for many Filipinos and policymakers can harness innovative practices from tech industries to improve business know-how of the common Juan..", className="mb-5"),

            ], className="page3 col-5"
        ),

          html.Div([
       dcc.RadioItems(id='raditem2',
                options = [{'label': year, 'value': year} for year in df_viz6b['Year'].unique()],
                value=df_viz6b['Year'].unique()[0],
                style={"width": "30%"}
            ),

        html.Div([
            dcc.Graph(id='donut_graph2')
        ]),
     ], className = 'col-7'),
    ], className = "row"),

     # Group
    html.Div([
        html.Div([
           dcc.RadioItems(id='raditem',
                options = [{'label': year, 'value': year} for year in df_viz7['Year'].unique()],
                value=df_viz7['Year'].unique()[0],
                style={"width": "50%"}
            ),

    html.Div([
        dcc.Graph(id='bar_graph', animate = True)
    ]),
    ], className = 'col-6'),

        html.Div([
            html.H6("2022 saw a decrease in the number of unemployed people, with 25-34 and 55 and above age groups as a crucial group to support", className="mb-5"),
            html.P("The distribution of unemployed people is concentrated in the younger age groups. For 15 to 24 year olds, this is understandable since they are still students, but the high numbers for 25-34 year olds require more attention as financial and professional stability at this stage of life are predictors for quality of life later on. Moreover, despite their  low numbers, older age groups should not be overlooked as unexpected catastrophies such as COVID-19 or technolgoy advancement like generative AI could render them jobless without 21st century skills. The 55 and above age groups in particular may have the most difficulty in accessing this kind of learning.", className="mb-5"),
           ], className="page3 col-6"),
    ], className = "row"),

])

@app.callback(
    Output('Map_02', 'figure'),
    Input('choropleth-select_1', 'value')
)

def update_map_02(selected_metric_02):
    column = None

    if selected_metric_02 != None:
      column = selected_metric_02

      start_color = np.array([255, 255, 255])  # RGB values for white
      end_color = np.array([154, 98, 164])  # RGB values for #9a62a4
      num_colors = 11
      color_scale = [tuple(np.round(start_color + i / (num_colors - 1) * (end_color - start_color)).astype(int)) for i in range(num_colors)]
      color_scale = [f'rgb{color}' for color in color_scale]

      fig_map = px.choropleth_mapbox(merged_region_0,
                                     geojson=merged_region_0.geometry,
                                     locations=merged_region_0.index,
                                     color=column,
                                     color_continuous_scale=color_scale,
                                     zoom=4.5,
                                     mapbox_style='light',
                                     center={"lat": 12.120649, "lon": 122.610799},
                                     hover_data={'Region': True},
                                     custom_data=['Region'])

    fig_map.update_traces(
          hovertemplate="<b>Region:</b> %{customdata[0]}<br><b>" + column + ":</b> %{z:.2f}%<extra></extra>")

    fig_map.update_layout(height=600,margin={"r":0,"t":0,"l":0,"b":0})

    return fig_map


@app.callback(
    Output("donut_graph1", "figure"),
    [Input("raditem1", "value")]
)

def update_graph(my_raditem1):
    filtered_df_viz6a = df_viz6a[df_viz6a['Year'] == my_raditem1]

    custom_color_map_1 ={'Self-Employed': '#9a62a4',
                         'Unpaid Family Worker': '#9a98b5',
                         'Wage and Salary Workers': '#a0b9c6',
                         'Employer': '#fcb97d'}

    don1 = px.pie(filtered_df_viz6a, values='Number of Workers', names='Type of Worker', title = "Classification of Employed Workers", hole=.5, color= 'Type of Worker',color_discrete_map=custom_color_map_1)
    don1.update_layout(transition_duration=500)

    return don1

@app.callback(
    Output("donut_graph2", "figure"),
    [Input("raditem2", "value")]
)

def update_graph(my_raditem2):
    filtered_df_viz6b = df_viz6b[df_viz6b['Year'] == my_raditem2]

    custom_color_map_2 ={'Private Household': '#9a98b5',
                         'Private Establishment': '#a0b9c6',
                         'Government or Government Corporation': '#9a62a4',
                         'Family-Operated Business': '#fcb97d'}

    don2 = px.pie(filtered_df_viz6b, values='Number of Wage and Salary Workers', names='Type of Wage and Salary Worker', title = "Classification of Wage & Salary Workers", hole=.5, color= 'Type of Wage and Salary Worker',color_discrete_map=custom_color_map_2)
    don2.update_layout(transition_duration=500)

    return don2

@app.callback(
    Output("bar_graph", "figure"),
    [Input("raditem", "value")]
)

def update_graph(my_raditem):
    filtered_df_viz7 = df_viz7[df_viz7['Year'] == my_raditem]
    bar_age = px.bar(filtered_df_viz7, x="Age Range", y="Number of Unemployed Workers", text="Number of Unemployed Workers", title = "Age Distribution of Unemployed Workers",color ="Age Range", color_discrete_sequence=['#9a62a4'])
    bar_age.update_traces(textposition="auto")
    bar_age.update_layout(transition_duration=500) # set the duration of the transition
 #   fig.update_layout(yaxis_tickformat = ',')
    return bar_age

@app.callback(
    Output("Viz4", "figure"),
    [Input("raditem4", "value"),
     Input("raditem3", "value"),
     Input("checklist_viz4", "value")]
)

def update_graph(raditem_year,raditem_type,checklist_region):
  L_Keys = ['REGION I - ILOCOS REGION',
          'REGION II - CAGAYAN VALLEY',
          'REGION III - CENTRAL LUZON',
          'REGION IVA - CALABARZON',
          'REGION V - BICOL REGION',
          'NCR',
          'CAR',
          'MIMAROPA']

  V_Keys = ['REGION VI - WESTERN VISAYAS',
          'REGION VII - CENTRAL VISAYAS',
          'REGION VIII - EASTERN VISAYAS']

  M_Keys = ['REGION IX - ZAMBOANGA PENINSULA',
          'REGION X - NORTHERN MINDANAO',
          'REGION XI - DAVAO REGION',
          'REGION XII - SOCCSKSARGEN',
          'REGION XIII - CARAGA',
          'BARMM']

  LV_Keys = ['REGION I - ILOCOS REGION',
          'REGION II - CAGAYAN VALLEY',
          'REGION III - CENTRAL LUZON',
          'REGION IVA - CALABARZON',
          'REGION V - BICOL REGION',
          'NCR',
          'CAR',
          'MIMAROPA',
          'REGION VI - WESTERN VISAYAS',
          'REGION VII - CENTRAL VISAYAS',
          'REGION VIII - EASTERN VISAYAS']

  LM_Keys = ['REGION I - ILOCOS REGION',
          'REGION II - CAGAYAN VALLEY',
          'REGION III - CENTRAL LUZON',
          'REGION IVA - CALABARZON',
          'REGION V - BICOL REGION',
          'NCR',
          'CAR',
          'MIMAROPA',
          'REGION IX - ZAMBOANGA PENINSULA',
          'REGION X - NORTHERN MINDANAO',
          'REGION XI - DAVAO REGION',
          'REGION XII - SOCCSKSARGEN',
          'REGION XIII - CARAGA',
          'BARMM']

  VM_Keys = ['REGION VI - WESTERN VISAYAS',
          'REGION VII - CENTRAL VISAYAS',
          'REGION VIII - EASTERN VISAYAS',
          'REGION IX - ZAMBOANGA PENINSULA',
          'REGION X - NORTHERN MINDANAO',
          'REGION XI - DAVAO REGION',
          'REGION XII - SOCCSKSARGEN',
          'REGION XIII - CARAGA',
          'BARMM']

  colors_LD = ['#fcb97d','#fcb97d','#fcb97d','#fcb97d','#fcb97d','#fcb97d','#fcb97d','#fcb97d']
  colors_VD = ['#a0b9c6','#a0b9c6','#a0b9c6']
  colors_MD = ['#9a98b5','#9a98b5','#9a98b5','#9a98b5','#9a98b5','#9a98b5']

  colors_LL = ['#ffeede','#ffeede','#ffeede','#ffeede','#ffeede','#ffeede','#ffeede','#ffeede']
  colors_VL = ['#c9dee9','#c9dee9','#c9dee9']
  colors_ML = ['#d2d0e9','#d2d0e9','#d2d0e9','#d2d0e9','#d2d0e9','#d2d0e9']

  df = pd.read_csv('df_final.csv')

  if raditem_year == '2021':
    df = df[df['Date'] == '10/1/2021']
    df_final = df_2021.groupby(by='Region').mean();
    df_final_noPH = df_final[df_final.index != 'Philippines']
    sorted = df_final_noPH.sort_values(by='Labor_Force_Participation_E').index
    region_dict = dict(zip(sorted,range(0,len(sorted))))

  elif raditem_year == '2022':
    df = df.drop(index=df[df['Date'] == '10/1/2021'].index)
    df_final = df_2022.groupby(by='Region').mean();
    df_final_noPH = df_final[df_final.index != 'Philippines']
    sorted = df_final_noPH.sort_values(by='Labor_Force_Participation_E').index
    region_dict = dict(zip(sorted,range(0,len(sorted))))

  if raditem_type == 'Labor Force':
    Average_Labor_Force = df_final_noPH['Labor_Force_Participation_E'].mean()

    if 'Luzon' in checklist_region and len(checklist_region) == 1:
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        df_final_noPH = df_final_noPH.loc[L]

        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon')
        data = [trace_1]
        layout = {
          'title': "Labor Force for Luzon",
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': L,
                    'title': 'Regions'},
          'shapes': [{
              'type': 'line',
              'x0': Average_Labor_Force,
              'y0': 0,
              'x1': Average_Labor_Force,
              'y1': len(L)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Labor_Force,
              'y': len(L) + 0.1,
              'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'xaxis': {'title': f"{raditem_type}"
              }}
        fig = go.Figure(data=data, layout=layout)

    elif 'Visayas' in checklist_region and len(checklist_region) == 1:
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        df_final_noPH = df_final_noPH.loc[V]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas')
        data = [trace_1]
        layout = {
            'title': "Labor Force for Visayas",
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': V,
                      'title': 'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Labor_Force,
                'y0': 0,
                'x1': Average_Labor_Force,
                'y1': len(V)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Labor_Force,
                'y': len(V) + 0.1,
                'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'xaxis': {'title': f"{raditem_type}"
                  }}
        fig = go.Figure(data=data, layout=layout)

    elif 'Mindanao' in checklist_region and len(checklist_region) == 1:
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao')
        data = [trace_1]
        layout = {
            'title': "Labor Force for Mindanao",
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': M,
                      'title': 'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Labor_Force,
                'y0': 0,
                'x1': Average_Labor_Force,
                'y1': len(M)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Labor_Force,
                'y': len(M) + 0.1,
                'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'xaxis': {'title': f"{raditem_type}"}
                  }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Visayas' in checklist_region and len(checklist_region) == 2:
        LV_Index = []
        for key in region_dict:
          if key in LV_Keys:
            LV_Index.append(region_dict[key])
        LV = sorted[LV_Index]
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        df_final_noPH = df_final_noPH.loc[LV]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_V = df_final_noPH.loc[V]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon')
        trace_2 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas')

        data = [trace_1,trace_2]
        layout = {
            'title':"Labor Force for Luzon and Visayas",
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': LV,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Labor_Force,
                'y0': 0,
                'x1': Average_Labor_Force,
                'y1': len(LV)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Labor_Force,
                'y': len(LV) + 0.1,
                'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 2:
        LM_Index = []
        for key in region_dict:
          if key in LM_Keys:
            LM_Index.append(region_dict[key])
        LM = sorted[LM_Index]
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[LM]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon')
        trace_2 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao')
        data = [trace_1,trace_2]
        layout = {
            'title':"Labor Force for Luzon and Mindanao",
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': LM,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Labor_Force,
                'y0': 0,
                'x1': Average_Labor_Force,
                'y1': len(LM)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Labor_Force,
                'y': len(LM) + 0.1,
                'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Visayas' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 2:
        VM_Index = []
        for key in region_dict:
          if key in VM_Keys:
            VM_Index.append(region_dict[key])
        VM = sorted[VM_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[VM]
        df_final_noPH_V = df_final_noPH.loc[V]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas')
        trace_2 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao')
        data = [trace_1,trace_2]
        layout = {
            'title':'Labor Force for Visayas and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': VM,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Labor_Force,
                'y0': 0,
                'x1': Average_Labor_Force,
                'y1': len(VM)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Labor_Force,
                'y': len(VM) + 0.1,
                'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Visayas' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 3:
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[sorted]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_V = df_final_noPH.loc[V]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon')
        trace_2 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas')
        trace_3 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao')

        data = [trace_1,trace_2,trace_3]
        layout = {
            'title':'Labor Force for Luzon, Visayas, and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': sorted,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Labor_Force,
                'y0': 0,
                'x1': Average_Labor_Force,
                'y1': len(sorted)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Labor_Force,
                'y': len(sorted) + 0.1,
                'text': f"Average Labor Force Participation: {int(Average_Labor_Force)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

  elif raditem_type == 'Labor Force and Unemployment':
    Average_Labor_Force = df_final_noPH['Labor_Force_Participation_E'].mean()
    Average_Unemployed = df_final_noPH['Unemployed_E'].mean()

    if 'Luzon' in checklist_region and len(checklist_region) == 1:
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        df_final_noPH = df_final_noPH.loc[L]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')

        trace_2 = go.Bar(x=df_final_noPH['Unemployed_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Unemployed')
        data = [trace_1,trace_2]
        layout = {
          'title':"Labor Force and Unemployment for Luzon",
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': L,
                    'title':'Regions'},
          'shapes': [{
              'type': 'line',
              'x0': Average_Unemployed,
              'y0': 0,
              'x1': Average_Unemployed,
              'y1': len(L)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Unemployed,
              'y': len(L) + 0.1,
              'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'barmode':'overlay',
          'xaxis': {'title': f"{raditem_type}"}
              }
        fig = go.Figure(data=data, layout=layout)

    elif 'Visayas' in checklist_region and len(checklist_region) == 1:
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        df_final_noPH = df_final_noPH.loc[V]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH['Unemployed_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Unemployed')
        data = [trace_1,trace_2]
        layout = {
          'title':'Labor Force and Unemployment for Visayas',
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': V,
                    'title':'Regions'},
          'shapes': [{
              'type': 'line',
              'x0': Average_Unemployed,
              'y0': 0,
              'x1': Average_Unemployed,
              'y1': len(V)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Unemployed,
              'y': len(V) + 0.1,
              'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'barmode':'overlay',
          'xaxis': {'title': f"{raditem_type}"}
              }
        fig = go.Figure(data=data, layout=layout)

    elif 'Mindanao' in checklist_region and len(checklist_region) == 1:
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH['Unemployed_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Unemployed')
        data = [trace_1,trace_2]
        layout = {
          'title':'Labor Force and Unemployment for Mindanao',
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': M,
                    'title':'Regions'},
          'shapes': [{
              'type': 'line',
              'x0': Average_Unemployed,
              'y0': 0,
              'x1': Average_Unemployed,
              'y1': len(M)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Unemployed,
              'y': len(M) + 0.1,
              'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'barmode':'overlay',
          'xaxis': {'title': f"{raditem_type}"}
              }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Visayas' in checklist_region and len(checklist_region) == 2:
        LV_Index = []
        for key in region_dict:
          if key in LV_Keys:
            LV_Index.append(region_dict[key])
        LV = sorted[LV_Index]
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        df_final_noPH = df_final_noPH.loc[LV]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_V = df_final_noPH.loc[V]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_L['Unemployed_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Unemployed')
        trace_3 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_V['Unemployed_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Unemployed')
        data = [trace_1,trace_2,trace_3,trace_4]
        layout = {
            'title':'Labor Force and Unemployment for Luzon and Visayas',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': LV},
            'shapes': [{
                'type': 'line',
                'x0': Average_Unemployed,
                'y0': 0,
                'x1': Average_Unemployed,
                'y1': len(LV)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Unemployed,
                'y': len(LV) + 0.1,
                'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 2:
        LM_Index = []
        for key in region_dict:
          if key in LM_Keys:
            LM_Index.append(region_dict[key])
        LM = sorted[LM_Index]
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[LM]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_L['Unemployed_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Unemployed')
        trace_3 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_M['Unemployed_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Unemployed')
        data = [trace_1,trace_2,trace_3,trace_4]
        layout = {
            'title':'Labor Force and Unemployment for Luzon and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': LM},
            'shapes': [{
                'type': 'line',
                'x0': Average_Unemployed,
                'y0': 0,
                'x1': Average_Unemployed,
                'y1': len(LM)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Unemployed,
                'y': len(LM) + 0.1,
                'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Visayas' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 2:
        VM_Index = []
        for key in region_dict:
          if key in VM_Keys:
            VM_Index.append(region_dict[key])
        VM = sorted[VM_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[VM]
        df_final_noPH_V = df_final_noPH.loc[V]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_V['Unemployed_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Unemployed')
        trace_3 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_M['Unemployed_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Unemployed')
        data = [trace_1,trace_2,trace_3,trace_4]
        layout = {
            'title':'Labor Force and Unemployment for Visayas and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': VM,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Unemployed,
                'y0': 0,
                'x1': Average_Unemployed,
                'y1': len(VM)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Unemployed,
                'y': len(VM) + 0.1,
                'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{Type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Visayas' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 3:
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[sorted]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_V = df_final_noPH.loc[V]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_L['Unemployed_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Unemployed')
        trace_3 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_V['Unemployed_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Unemployed')
        trace_5 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_6 = go.Bar(x=df_final_noPH_M['Unemployed_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Unemployed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Unemployed')
        data = [trace_1,trace_2,trace_3,trace_4,trace_5,trace_6]
        layout = {
            'title':'Labor Force and Unemployment for Luzon, Visayas, and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': sorted,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Unemployed,
                'y0': 0,
                'x1': Average_Unemployed,
                'y1': len(sorted)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Unemployed,
                'y': len(sorted) + 0.1,
                'text': f"Average No. of Unemployed: {int(Average_Unemployed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

  elif raditem_type == 'Labor Force and Employment':
    Average_Labor_Force = df_final_noPH['Labor_Force_Participation_E'].mean()
    Average_Employed = df_final_noPH['Employed_E'].mean()

    if 'Luzon' in checklist_region and len(checklist_region) == 1:
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        df_final_noPH = df_final_noPH.loc[L]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH['Employed_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Employed')
        data = [trace_1,trace_2]
        layout = {
          'title':'Labor Force and Employment for Luzon',
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': L,
                    'title':'Regions'},
          'shapes': [{
              'type': 'line',
              'x0': Average_Employed,
              'y0': 0,
              'x1': Average_Employed,
              'y1': len(L)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Employed,
              'y': len(L) + 0.1,
              'text': f"Average No. of Employed: {int(Average_Employed)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'barmode':'overlay',
          'xaxis': {'title': f"{raditem_type}"}
              }
        fig = go.Figure(data=data, layout=layout)

    elif 'Visayas' in checklist_region and len(checklist_region) == 1:
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        df_final_noPH = df_final_noPH.loc[V]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH['Employed_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Employed')
        data = [trace_1,trace_2]
        layout = {
          'title':'Labor Force and Employment for Visayas',
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': V,
                    'title':'Regions'},
          'shapes': [{
              'type': 'line',
              'x0': Average_Employed,
              'y0': 0,
              'x1': Average_Employed,
              'y1': len(V)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Employed,
              'y': len(V) + 0.1,
              'text': f"Average No. of Employed: {int(Average_Employed)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'barmode':'overlay',
          'xaxis': {'title': f"{raditem_type}"}
              }
        fig = go.Figure(data=data, layout=layout)

    elif 'Mindanao' in checklist_region and len(checklist_region) == 1:
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH['Labor_Force_Participation_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH['Employed_E'],
                        y=df_final_noPH.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Employed')
        data = [trace_1,trace_2]
        layout = {
          'title':'Labor Force and Employment for Mindanao',
          'yaxis': {'categoryorder': 'array',
                    'categoryarray': M},
          'shapes': [{
              'type': 'line',
              'x0': Average_Employed,
              'y0': 0,
              'x1': Average_Employed,
              'y1': len(M)-1,
              'line': {
                  'color': 'black',
                  'width': 2}}],
          'annotations': [{
              'x': Average_Employed,
              'y': len(M) + 0.1,
              'text': f"Average No. of Employed: {int(Average_Employed)}",
              'showarrow': False,
              'font': {'size': 16, 'color': 'black'}}],
          'barmode':'overlay',
          'xaxis': {'title': f"{raditem_type}"}
              }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Visayas' in checklist_region and len(checklist_region) == 2:
        LV_Index = []
        for key in region_dict:
          if key in LV_Keys:
            LV_Index.append(region_dict[key])
        LV = sorted[LV_Index]
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        df_final_noPH = df_final_noPH.loc[LV]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_V = df_final_noPH.loc[V]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_L['Employed_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Employed')
        trace_3 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_V['Employed_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Employed')
        data = [trace_1,trace_2,trace_3,trace_4]
        layout = {
            'title':'Labor Force and Employment for Luzon and Visayas',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': LV,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Employed,
                'y0': 0,
                'x1': Average_Employed,
                'y1': len(LV)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Employed,
                'y': len(LV) + 0.1,
                'text': f"Average No. of Employed: {int(Average_Employed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 2:
        LM_Index = []
        for key in region_dict:
          if key in LM_Keys:
            LM_Index.append(region_dict[key])
        LM = sorted[LM_Index]
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[LM]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_L['Employed_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Employed')
        trace_3 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_M['Employed_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Employed')
        data = [trace_1,trace_2,trace_3,trace_4]
        layout = {
            'title':'Labor Force and Employment for Luzon and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': LM,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Employed,
                'y0': 0,
                'x1': Average_Employed,
                'y1': len(LM)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Employed,
                'y': len(LM) + 0.1,
                'text': f"Average No. of Employed: {int(Average_Employed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Visayas' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 2:
        VM_Index = []
        for key in region_dict:
          if key in VM_Keys:
            VM_Index.append(region_dict[key])
        VM = sorted[VM_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[VM]
        df_final_noPH_V = df_final_noPH.loc[V]
        df_final_noPH_M = df_final_noPH.loc[M]
        trace_1 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participants')
        trace_2 = go.Bar(x=df_final_noPH_V['Employed_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Employed')
        trace_3 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participants')
        trace_4 = go.Bar(x=df_final_noPH_M['Employed_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Employed')
        data = [trace_1,trace_2,trace_3,trace_4]
        layout = {
            'title':'Labor Force and Employment for Visayas and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': VM,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Employed,
                'y0': 0,
                'x1': Average_Employed,
                'y1': len(VM)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Employed,
                'y': len(VM) + 0.1,
                'text': f"Average No. of Employed: {int(Average_Employed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                }
        fig = go.Figure(data=data, layout=layout)

    elif 'Luzon' in checklist_region and 'Visayas' in checklist_region and 'Mindanao' in checklist_region and len(checklist_region) == 3:
        L_Index = []
        for key in region_dict:
          if key in L_Keys:
            L_Index.append(region_dict[key])
        L = sorted[L_Index]
        V_Index = []
        for key in region_dict:
          if key in V_Keys:
            V_Index.append(region_dict[key])
        V = sorted[V_Index]
        M_Index = []
        for key in region_dict:
          if key in M_Keys:
            M_Index.append(region_dict[key])
        M = sorted[M_Index]
        df_final_noPH = df_final_noPH.loc[sorted]
        df_final_noPH_L = df_final_noPH.loc[L]
        df_final_noPH_V = df_final_noPH.loc[V]
        df_final_noPH_M = df_final_noPH.loc[M]

        trace_1 = go.Bar(x=df_final_noPH_L['Labor_Force_Participation_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Luzon Labor Force Participation')
        trace_2 = go.Bar(x=df_final_noPH_L['Employed_E'],
                        y=df_final_noPH_L.index,
                        orientation='h',
                        marker={'color':colors_LL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Luzon No. of Employed')
        trace_3 = go.Bar(x=df_final_noPH_V['Labor_Force_Participation_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Visayas Labor Force Participation')
        trace_4 = go.Bar(x=df_final_noPH_V['Employed_E'],
                        y=df_final_noPH_V.index,
                        orientation='h',
                        marker={'color':colors_VL},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Visayas No. of Employed')
        trace_5 = go.Bar(x=df_final_noPH_M['Labor_Force_Participation_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_MD},
                        hovertemplate='Labor Force Participation: %{x:.2f}<extra></extra>',
                        name='Mindanao Labor Force Participation')
        trace_6 = go.Bar(x=df_final_noPH_M['Employed_E'],
                        y=df_final_noPH_M.index,
                        orientation='h',
                        marker={'color':colors_ML},
                        hovertemplate='No. of Employed: %{x:.2f}<extra></extra>',
                        name='Mindanao No. of Employed')
        data = [trace_1,trace_2,trace_3,trace_4,trace_5,trace_6]
        layout = {
            'title':'Labor Force and Employment for Luzon, Visayas, and Mindanao',
            'yaxis': {'categoryorder': 'array',
                      'categoryarray': sorted,
                      'title':'Regions'},
            'shapes': [{
                'type': 'line',
                'x0': Average_Employed,
                'y0': 0,
                'x1': Average_Employed,
                'y1': len(sorted)-1,
                'line': {
                    'color': 'black',
                    'width': 2}}],
            'annotations': [{
                'x': Average_Employed,
                'y': len(sorted) + 0.1,
                'text': f"Average No. of Employed: {int(Average_Employed)}",
                'showarrow': False,
                'font': {'size': 16, 'color': 'black'}}],
            'barmode':'overlay',
            'xaxis': {'title': f"{raditem_type}"}
                  }
        fig = go.Figure(data=data, layout=layout)

  return fig
