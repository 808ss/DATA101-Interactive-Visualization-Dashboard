# index.py
from dash import Dash, dcc, html, Input, Output
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc
from app import app
from apps import page1, page2, page3

app.layout = dbc.Container([
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])

@app.callback(Output('page-content', 'children'),
              Input('url', 'pathname'))
def display_page(pathname):
    if pathname == '/page1':
        return page1.layout
    elif pathname == '/page2':
        return page2.layout
    elif pathname == '/page3':
        return page3.layout
    else:
        return html.Div([
            html.Br(), html.Br(),
            html.Section([
                html.H2("Dashboard Guide on Key Employment Indicators in the Philippines", className="text-center mb-3"),
                html.H5("Highlighting the intersectionality of poverty and unemployment, this website seeks to aid policymakers in identifying untapped opportunities and challenges of Filipino workers through spatial, demographic, and financial data. This dashboard was created to be a reliable source for data-driven decisions in the creation of upskilling and technical education programs to ensure that resources and opportunities arrive to those who need them the most.", className="home-subheader text-center mb-5"),

                html.Div(className="row", children=[
                    html.Div(className="card-link col-md-4 col-sm-6 mb-4", children=[
                        dcc.Link(href="/page1", children=[
                            html.Div(className="card text-center", children=[
                                html.Div(className="card-body", children=[
                                    html.H6("Understanding Poverty", className="card-title"),
                                    html.P("How does income inequality look like across the country? Let data from the Family Income and Expenditures Survey tell us more.", className="card-text"),
                                ])
                            ])
                        ]),
                    ]),
                    html.Div(className="card-link col-md-4 col-sm-6 mb-4", children=[
                        dcc.Link(href="/page2", children=[
                            html.Div(className="card text-center", children=[
                                html.Div(className="card-body", children=[
                                    html.H5("Zooming in on Employment", className="card-title"),
                                    html.P("The annual Labor Force Survey gives us a glimpse of the state of our workforce and what we can find common about its subset of unemployed Filipinos", className="card-text"),
                                ])
                            ])
                        ]),
                    ]),
                    html.Div(className="card-link col-md-4 col-sm-6 mb-4", children=[
                        dcc.Link(href="/page3", children=[
                            html.Div(className="card text-center", children=[
                                html.Div(className="card-body", children=[
                                    html.H5("Finding Opportunities", className="card-title"),
                                    html.P("Bridging these two sets of data, we'll synthesize our findings and discover trends to be aware of so we can better capacitate our labor force.", className="card-text"),
                                ])
                            ])
                        ]),
                    ])
                ]),
            ]),
        ])

if __name__ == '__main__':
    app.run_server(debug=True)